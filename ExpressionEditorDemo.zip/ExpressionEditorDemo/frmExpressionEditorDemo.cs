﻿using DevExpress.XtraEditors;
using DevExpress.Data.Controls.ExpressionEditor;
using DevExpress.Data.Filtering;
using System.ComponentModel;
using DevExpress.Data.Filtering.Helpers;

namespace ExpressionEditorDemo
{
    public partial class frmExpressionEditorDemo : XtraForm
    {

        private readonly SampleAblationModel _sampleData = new();

        public static void Run() => new frmExpressionEditorDemo()?.Show();

        public frmExpressionEditorDemo()
        {
            InitializeComponent();
        }

        private static ExpressionEditorContext CreateExpressionEditorContext()
        {
            var context = new ExpressionEditorContext();
            context.Columns.AddRange(BuildColumnsFromType(typeof(SampleAblationModel)));
            return context;
        }

        private static string? ValidateExpression(string expression)
        {
            if (string.IsNullOrWhiteSpace(expression))
                return "⚠ Expression is empty.";

            try
            {
                var criteria = CriteriaOperator.Parse(expression);
                if (criteria is null) return "⚠ Parsed to null (empty expression).";
            }
            catch (Exception ex)
            {
                return $"✗ Validation error:\r\n{ex.Message}";
            }

            return null;
        }

        /// <summary>
        /// Builds a list of ColumnInfo from all public instance properties of the given type.
        /// </summary>
        private static List<ColumnInfo> BuildColumnsFromType(Type type)
        {
            var columns = new List<ColumnInfo>();
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(type);

            foreach (PropertyDescriptor prop in properties)
            {
                var col = new ColumnInfo
                {
                    Name = prop.Name,
                    Type = prop.PropertyType,
                    Description = prop.Description,
                };
                columns.Add(col);
            }

            return columns;
        }

        private void sbEditExpression_Click(object sender, EventArgs e)
        {
            string expression = meExpression.Text;
            var context = CreateExpressionEditorContext();

            using var view = new DevExpress.DataAccess.UI.ExpressionEditor.ExpressionEditorView(this.LookAndFeel, this);
            bool accepted = ExpressionEditorUIHelper.RunExpressionEditor(ref expression, view, context, ValidateExpression);
            if (accepted) meExpression.Text = expression;
            if (accepted) sbValidate_Click(sender, e);
        }

        private void sbValidate_Click(object sender, EventArgs e)
        {
            meResult.Text = ValidateExpression(meExpression.Text) ?? $"✓ Valid expression.";
        }

        private void sbEvaluate_Click(object sender, EventArgs e)
        {
            string expression = meExpression.Text;

            if (string.IsNullOrWhiteSpace(expression))
            {
                meResult.Text = "⚠ Expression is empty.";
                return;
            }

            try
            {
                var criteria = CriteriaOperator.Parse(expression);

                if (criteria is null)
                {
                    meResult.Text = "⚠ Parsed to null (empty expression).";
                    return;
                }

                PropertyDescriptorCollection properties =
                    TypeDescriptor.GetProperties(typeof(SampleAblationModel));

                ExpressionEvaluator evaluator = new(properties, criteria);
                object result = evaluator.Evaluate(_sampleData);

                meResult.Text =
                    $"✓ Result: {result}\r\n" +
                    $"   Type: {result?.GetType().Name ?? "null"}\r\n\r\n" +
                    $"Expression: {criteria}\r\n\r\n" +
                    $"Sample data:\r\n" +
                    $"   Power = {_sampleData.Power} W\r\n" +
                    $"   PulseFrequency = {_sampleData.PulseFrequency} Hz\r\n" +
                    $"   SpotSize = {_sampleData.SpotSize} µm\r\n" +
                    $"   ScanSpeed = {_sampleData.ScanSpeed} mm/s\r\n" +
                    $"   PulseDuration = {_sampleData.PulseDuration} ns";
            }
            catch (Exception ex)
            {
                meResult.Text = $"✗ Evaluation error:\r\n{ex.Message}";
            }
        }
    }
}
